# BPI · Shopify Theme (Dawn Mejorado)

Plantilla lista para **personalizar** desde Shopify y mantener **versionada** en GitHub.

## Qué incluye
- Home preconfigurada (Hero → Beneficios → Grid → Pedido COD por WhatsApp)
- Secciones BPI: hero, benefits, grid con %, formulario COD, cabecera SEO de colección, bloque confianza PDP.
- SEO avanzado: OG/Twitter, JSON-LD (Organization, WebSite/SearchAction, FAQ en Home).
- Botón flotante de WhatsApp global.
- `Theme CI` (GitHub Actions) con `theme-check` para bloquear errores en Liquid/JSON.

## Flujo recomendado
- `staging` → tema de **vista previa** (no publicado).
- `main` → tema **publicado**.

### Pasos
1. **Sube** este contenido a tu repositorio (raíz).
2. En Shopify: *Tienda online → Temas → Añadir tema → Conectar desde GitHub* → elige este repo y la rama `staging`.
3. Crea un segundo tema conectado a `main` (será el **publicado**).
4. En GitHub: *Settings → Branches* → protege `main` para exigir PR + CI verde.
5. Flujo de trabajo:
   - Rama `feat/...` → PR a `staging` → revisas en el tema de vista previa.
   - PR `staging` → `main` cuando esté listo → Shopify actualiza el tema publicado.

## Personalización (sin código)
- **Theme settings → BPI**: WhatsApp, Instagram/TikTok, imagen OG.
- **Home**: imagen/textos del Hero; beneficios; en **BPI · Grid** elige la colección **Guayos**.
- **Colección**: asigna plantilla `collection.bpi` (H1 + copy SEO + grid).
- **Producto**: asigna plantilla `product.bpi` (confianza + WhatsApp).

## Notas
- El ZIP trae un *Preview Guard* para evitar ver 404 en el **Customizer** cuando entras por una URL rota.
- Shopify **no** sincroniza menús/páginas/productos por Git (eso se gestiona en el Admin).

---

**Soporte**: si quieres ampliar el CI (Lighthouse, ESLint, tests), abre un issue o crea una rama `chore/ci`.
